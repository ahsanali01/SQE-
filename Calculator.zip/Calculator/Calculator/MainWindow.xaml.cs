﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Calculator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnCal_Click(object sender, RoutedEventArgs e)
        {
            if(rdBtnAdd.IsChecked==true)
            {
                txtExp.Text = txtLO.Text + " + " + txtRO.Text; 
                txtRslt.Text = addition();
            }
            else if (rdBtnSub.IsChecked==true)
            {
                txtExp.Text = txtLO.Text + " - " + txtRO.Text;
                txtRslt.Text = subtraction();
            }
            else if (rdBtnMul.IsChecked==true)
            {
                txtExp.Text = txtLO.Text + " * " + txtRO.Text;
                txtRslt.Text = multiply();
            }
            else if (rdBtnDiv.IsChecked==true)
            {
                txtExp.Text = txtLO.Text + " / " + txtRO.Text;
                txtRslt.Text = divide();
            }
            else
            {
                txtExp.Text = txtLO.Text + " % " + txtRO.Text;
                txtRslt.Text = remainder();
            }
        }

        string addition ()
        {
            float num1 = float.Parse(txtLO.Text);
            float num2 = float.Parse(txtRO.Text);

            float sum = num1 + num2;
            return sum.ToString();
        }
        string subtraction()
        {
            float num1 = float.Parse(txtLO.Text);
            float num2 = float.Parse(txtRO.Text);

            float sub = num1 - num2;
            return sub.ToString();
        }
        string multiply()
        {
            float num1 = float.Parse(txtLO.Text);
            float num2 = float.Parse(txtRO.Text);

            float mul = num1 * num2;
            return mul.ToString();
        }
        string divide()
        {
            float num1 = float.Parse(txtLO.Text);
            float num2 = float.Parse(txtRO.Text);

            float div = num1 / num2;
            return div.ToString();
        }
        string remainder()
        {
            float num1 = float.Parse(txtLO.Text);
            float num2 = float.Parse(txtRO.Text);

            float rem = num1 % num2;
            return rem.ToString();
        }

        private void btnQuit_Click(object sender, RoutedEventArgs e)
        {
            Environment.Exit(0);
        }
    }
}
